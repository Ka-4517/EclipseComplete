package Day2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.testng.annotations.Test;

import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

/*
 Different ways to create Request Body
 1)using Hashmap
 2)using org.json
 3)using POJO class
 4)json file data
 */
public class differentWaysToCreateRequestBody {
	//@Test
	void testPostusingHashmap()
	{
		HashMap<String, String> data=new HashMap<String, String>();
		data.put("username","karan_test@yopmail.com");
		data.put("password", "Karan123@");
		
		RestAssured.given()
		.contentType("application/json")
		.body(data)
		
		.when()
		.post("https://cadenabackend.iworklab.com/api/v1/api-user-login/")
		
		.then()
		.statusCode(200)
		.body("data[0].username", equalTo("New_user_Karan"))
		.body("data[0].full_name", equalTo("Karan Sahu"))
		.body("data[0].first_name", equalTo("Karan"))
		.body("data[0].last_name", equalTo("Sahu"))
		.body("data[0].company_name", equalTo("ValueCoders"))
		.body("data[0].phone_number", equalTo("+971-551629118"))
		.body("data[0].country_code", equalTo("ae"))
		.body("data[0].job_title", equalTo("QA"))
		.body("data[0].email", equalTo("karan_test@yopmail.com"))
		.header("Content-Type","application/json")
		.log().all();
		
		
																
	}
	//@Test(priority=2)
	void testPostUsingOrgJsonLibrary(){
		//Add org.json dependency in POM
//		HashMap<String, String> data=new HashMap<String, String>();
//		data.put("username","karan_test@yopmail.com");
//		data.put("password", "Karan123@");
		
		JSONObject data=new JSONObject();
		data.put("username","karan_test@yopmail.com");
		data.put("password", "Karan123@");
		
		
		RestAssured.given()
		.contentType("application/json")
		.body(data.toString())
		
		.when()
		.post("https://cadenabackend.iworklab.com/api/v1/api-user-login/")
		
		.then()
		.statusCode(200)
		.body("data[0].username", equalTo("New_user_Karan"))
		.body("data[0].full_name", equalTo("Karan Sahu"))
		.body("data[0].first_name", equalTo("Karan"))
		.body("data[0].last_name", equalTo("Sahu"))
		.body("data[0].company_name", equalTo("ValueCoders"))
		.body("data[0].phone_number", equalTo("+971-551629118"))
		.body("data[0].country_code", equalTo("ae"))
		.body("data[0].job_title", equalTo("QA"))
		.body("data[0].email", equalTo("karan_test@yopmail.com"))
		.header("Content-Type","application/json")
		.log().all();

		
	}
	//@Test(priority=1)
	void testPostusingPOJOClass() {
		POJOClass object=new POJOClass();
		object.setUsername("karan_test@yopmail.com");
		object.setPassword("Karan123@");
		
		
		RestAssured.given()
		.contentType("application/json")
		.body(object)
		
		.when()
		.post("https://cadenabackend.iworklab.com/api/v1/api-user-login/")
		
		.then()
		.statusCode(200)
		.body("data[0].username", equalTo("New_user_Karan"))
		.body("data[0].full_name", equalTo("Karan Sahu"))
		.body("data[0].first_name", equalTo("Karan"))
		.body("data[0].last_name", equalTo("Sahu"))
		.body("data[0].company_name", equalTo("ValueCoders"))
		.body("data[0].phone_number", equalTo("+971-551629118"))
		.body("data[0].country_code", equalTo("ae"))
		.body("data[0].job_title", equalTo("QA"))
		.body("data[0].email", equalTo("karan_test@yopmail.com"))
		.header("Content-Type","application/json")
		.log().all();
		
	}
	@Test(priority=3)
	void testUsingExternalFile() throws FileNotFoundException {
		File f=new File(".\\body.json");
		FileReader fr=new FileReader(f);
		JSONTokener jt=new JSONTokener(fr);
		JSONObject data=new JSONObject(jt); //now json converting to string
		
		RestAssured.given()
		.contentType("application/json")
		.body(data.toString())
		
		.when()
		.post("https://cadenabackend.iworklab.com/api/v1/api-user-login/")
		
		.then()
		.statusCode(200)
		.body("data[0].username", equalTo("New_user_Karan"))
		.body("data[0].full_name", equalTo("Karan Sahu"))
		.body("data[0].first_name", equalTo("Karan"))
		.body("data[0].last_name", equalTo("Sahu"))
		.body("data[0].company_name", equalTo("ValueCoders"))
		.body("data[0].phone_number", equalTo("+971-551629118"))
		.body("data[0].country_code", equalTo("ae"))
		.body("data[0].job_title", equalTo("QA"))
		.body("data[0].email", equalTo("karan_test@yopmail.com"))
		.header("Content-Type","application/json")
		.log().all();
	}

}

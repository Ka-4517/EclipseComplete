package CadenaCopy;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.response.Response;

public class GetAPITestCases {
	private String authToken;

	public GetAPITestCases() {
		authToken = "e1112dbda87ebee32612c1f2cad28ffd5dca316a";
	}

	@Test
	public void testGetAllUsers() {
		Response response = RestAssured.given().header("Authorization", "Token " + authToken)
				.get("http://cadenabackend.iworklab.com/api/v1/users/");
		System.out.println(response.statusCode());
		System.out.println(response.asString());
		System.out.println(response.getBody().asString());
		System.out.println(response.statusLine());

		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, 200);
	}

	@Test
	public void testGetUsersWithMultipleHeaders() {
		Map<String, String> headers = new HashMap<String, String>();// This line creates a new HashMap instance that
																	// will be used to store the headers for the HTTP
																	// request. The Map is parameterized to hold String
																	// keys and String values.
		headers.put("Authorization", "Token " + authToken);// This line adds an "Authorization" header to the headers
															// map. The value of this header is "Token " followed by the
															// value of the authToken variable. This header is often
															// used to authenticate the user making the request.
		headers.put("Content-Type", "application/json");// This line adds an "Accept" header to the headers map. The value of
													// this header is "application/json", which tells the server that
													// the client expects to receive a response in JSON format.

		Response response = RestAssured.given().headers(headers).get("http://cadenabackend.iworklab.com/api/v1/users/");
		// This line creates a new RequestSpecification instance using the given()
		// method provided by RestAssured. The headers map is passed to the headers()
		// method of this RequestSpecification to set the headers for the request.
		// Finally, the RequestSpecification is used to send the HTTP request, and the
		// response is stored in a Response object named response.

		System.out.println(response.statusCode());

		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, 200);
		// Overall, this code sets the headers for an HTTP request using the RestAssured
		// library and sends the request, storing the response in a Response object.

	}

	@Test
	public void testGetUserById() {
		Response response = RestAssured.given().header("Authorization", "Token " + authToken)
				.get("http://cadenabackend.iworklab.com/api/v1/users/1/");

		System.out.println(response.asString());

		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, 200);
		Assert.assertTrue(response.getBody().asString().contains("SunilRSaini"));
	}

	@Test
	public void testGetUserByIdWithKeyValues() {
		Response response = RestAssured.given().header("Authorization", "Token " + authToken)
				.get("http://cadenabackend.iworklab.com/api/v1/users/1/");

		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, 200);
		Assert.assertEquals(response.jsonPath().get("username"), "SunilRSaini");
		Assert.assertEquals(response.jsonPath().get("email"), "sunil.saini@mail.vinove.com");
	}

}
